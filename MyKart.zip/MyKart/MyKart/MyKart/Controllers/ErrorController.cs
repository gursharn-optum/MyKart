﻿using System.Web.Mvc;

namespace MyKart.Controllers
{
    public class ErrorController : Controller
    {
        public ActionResult Index()
        {
            // TODO: Add custom error messages support

            return View("Error");
        }
    }
}