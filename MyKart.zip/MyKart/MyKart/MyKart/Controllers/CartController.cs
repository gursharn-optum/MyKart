﻿using MyKart.Core;
using MyKart.Core.Models;
using MyKart.Core.ViewModels;
using MyKart.Persistence;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MyKart.Controllers
{
    [Authorize]
    public class CartController : Controller
    {
        private readonly IUnitOfWork unitOfWork = new UnitOfWork();
        public ActionResult Index()
        {
            List<ProductViewModel> Cart = (List<ProductViewModel>) Session["Cart"];

            ViewBag.GrandTotal = 0;

            if (Cart == null)
                return View(Cart);

            if (Cart.Count < 1)
                return View(Cart);

            foreach (var productVM in Cart)
                    ViewBag.GrandTotal = ViewBag.GrandTotal + productVM.TotalPrice;

            Session["GrandTotal"] = ViewBag.GrandTotal;

            return View(Cart);
        }

        public ActionResult Add(int? id)
        {
            Product product = unitOfWork.Products.Get(id);

            if (product == null)
                return RedirectToAction("Index");

            ProductViewModel productVM = new ProductViewModel();
            productVM.Product = product;
            productVM.Quantity = 1;

            return View(productVM);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add([Bind (Exclude = "TotalPrice")] ProductViewModel productVM)
        {
            if (ModelState.IsValid)
            {
                List<ProductViewModel> Cart = (List<ProductViewModel>) Session["Cart"];

                if (Cart == null)
                    Cart = new List<ProductViewModel>();

                // Remove existing duplicate products in cart
                if (Cart.Exists(m => m.Product.ID == productVM.Product.ID))
                    Cart.RemoveAll(m => m.Product.ID == productVM.Product.ID);

                Cart.Add(productVM);

                Session["Cart"] = Cart;

                return RedirectToAction("Index");
            }

            return View();
        }

        public ActionResult Remove(int? id)
        {
            List<ProductViewModel> Cart = (List<ProductViewModel>) Session["Cart"];

            if (Cart == null || id == null)
                return RedirectToAction("Index");

            Cart.RemoveAll(m => m.Product.ID == id);
            Session["Cart"] = Cart;

            return RedirectToAction("Index");
        }
    }
}