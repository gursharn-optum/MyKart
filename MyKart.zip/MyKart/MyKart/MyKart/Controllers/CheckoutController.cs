﻿using System.Web.Mvc;

namespace MyKart.Controllers
{
    [Authorize]
    public class CheckoutController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.GrandTotal = Session["GrandTotal"];
            return View();
        }
    }
}