﻿using MyKart.Core.Models;

namespace MyKart.Core.Repositories
{
    public interface IUserRepository
    {
        void Add(User newUser);
        bool Exists(string userName);
        bool ValidateUser(User user);
    }
}
