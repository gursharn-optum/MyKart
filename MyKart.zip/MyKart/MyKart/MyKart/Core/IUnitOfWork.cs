﻿using MyKart.Core.Repositories;

namespace MyKart.Core
{
    public interface IUnitOfWork
    {
        IUserRepository Users { get; }
        IProductRepository Products { get; }
        void Complete();
    }
}
