﻿using System.ComponentModel.DataAnnotations;

namespace MyKart.Core.Models
{
    public class User
    {
        [Key]
        [Required]
        [MinLength(4)]
        [MaxLength(10)]
        public string UserName { get; set; }

        [Required]
        [MinLength(8)]
        [MaxLength(15)]
        public string Password { get; set; }

        // TODO: Add email for Password Recovery
    }
}