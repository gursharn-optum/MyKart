﻿using MyKart.Core;
using MyKart.Core.Repositories;
using MyKart.Persistence.Repositories;

namespace MyKart.Persistence
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly MyKartContext db;
        public IProductRepository Products { get; private set; }

        public IUserRepository Users { get; private set; }

        public UnitOfWork()
        {
            db = new MyKartContext();
            Products = new ProductRepository(db);
            Users = new UserRepository(db);
        }
        public void Complete()
        {
            db.SaveChanges();
        }
    }
}