﻿using MyKart.Core.Models;
using MyKart.Core.Repositories;
using System.Linq;

namespace MyKart.Persistence.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly MyKartContext db;

        public UserRepository(MyKartContext db)
        {
            this.db = db;
        }
        public void Add(User newUser)
        {
            db.Users.Add(newUser);
        }

        public bool Exists(string userName)
        {
            return db.Users.Any(m => m.UserName == userName);
        }

        public bool ValidateUser(User user)
        {
            string username = user.UserName;
            string password = user.Password;

            return db.Users.Any(m => m.UserName == username && m.Password == password);
        }
    }
}