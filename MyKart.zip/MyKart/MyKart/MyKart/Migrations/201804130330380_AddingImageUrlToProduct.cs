namespace MyKart.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddingImageUrlToProduct : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Products", "ImageLink", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Products", "ImageLink");
        }
    }
}
