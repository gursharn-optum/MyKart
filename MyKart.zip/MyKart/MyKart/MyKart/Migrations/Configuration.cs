using System;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;

namespace MyKart.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<MyKart.Persistence.MyKartContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "MyKart.Models.MyKartContext";
        }
    }
}
