﻿using System.ComponentModel.DataAnnotations;

namespace MyKart.Core.Models
{
    public class Product
    {
        public int ID { get; set; }

        [Required]
        [MinLength(2)]
        [MaxLength(20)]
        public string Name { get; set; }

        [Required]
        [Range(minimum: 1, maximum: 100)]
        public int Price { get; set; }

        [Required]
        [Url]
        public string ImageLink { get; set; }
    }
}