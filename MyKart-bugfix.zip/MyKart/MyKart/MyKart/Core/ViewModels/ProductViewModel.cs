﻿using MyKart.Core.Models;
using System.ComponentModel.DataAnnotations;

namespace MyKart.Core.ViewModels
{
    public class ProductViewModel
    {
        public Product Product { get; set; }

        [Required]
        [Range(minimum: 1, maximum: 10)]
        public int Quantity { get; set; }

        public int TotalPrice
        {
            get
            {
                return Quantity * Product.Price;
            }
        }
    }
}