﻿using MyKart.Core.Models;
using System.Collections.Generic;

namespace MyKart.Core.Repositories
{
    public interface IProductRepository
    {
        void Add(Product newProduct);
        Product Get(int? id);
        List<Product> GetAll();
        void Update(Product product);
        void Delete(Product product);
    }
}
