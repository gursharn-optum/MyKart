﻿using MyKart.Core.ViewModels;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MyKart.Controllers
{
    [Authorize]
    public class CheckoutController : Controller
    {
        public ActionResult Index()
        {
            List<ProductViewModel> Cart = (List<ProductViewModel>)Session["Cart"];

            if (Cart == null)
                ViewBag.GrandTotal = null;
            else
            {
                if (Cart.Count < 1)
                    ViewBag.GrandTotal = null;
                else
                    ViewBag.GrandTotal = Session["GrandTotal"];
            }

            return View();
        }
    }
}