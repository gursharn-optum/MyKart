﻿using MyKart.Core;
using MyKart.Core.Models;
using MyKart.Core.ViewModels;
using MyKart.Persistence;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Security;

namespace MyKart.Controllers
{
    public class UsersController : Controller
    {
        private readonly IUnitOfWork unitOfWork = new UnitOfWork();
        public ActionResult Create()
        {
            if (User.Identity.IsAuthenticated)
                return RedirectToAction("Index", "Products", new { });

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(User newUser)
        {
            if (ModelState.IsValid)
            {
                if (unitOfWork.Users.Exists(newUser.UserName))
                {
                    ViewBag.Error = "This UserName is already in use.";
                }
                else
                {
                    unitOfWork.Users.Add(newUser);
                    unitOfWork.Complete();

                    FormsAuthentication.SetAuthCookie(newUser.UserName, false);
                    FormsAuthentication.RedirectFromLoginPage(newUser.UserName, false);
                }
            }

            return View();
        }

        public ActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
                return RedirectToAction("Index", "Products", new { });

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User user)
        {
            if (ModelState.IsValid)
            {

                bool isValid = unitOfWork.Users.ValidateUser(user);

                if (isValid)
                {
                    Session["Cart"] = new List<ProductViewModel>();
                    FormsAuthentication.SetAuthCookie(user.UserName, false);
                    FormsAuthentication.RedirectFromLoginPage(user.UserName, false);
                }
                else
                {
                    ViewBag.Error = "UserName and/or Password are invalid.";
                }
            }
            return View();
        }

        public ActionResult LogOut()
        {
            if (Request.UrlReferrer.AbsolutePath == "/Users/Login")
            {
                return RedirectToAction("Index", "Products");
            }

            if (User.Identity.IsAuthenticated)
            {
                Session.Clear();
                FormsAuthentication.SignOut();
                FormsAuthentication.RedirectToLoginPage();
            }
            return View("Login");
        }
    }
}