﻿using MyKart.Core.Models;
using System.Data.Entity;

namespace MyKart.Persistence
{
    public class MyKartContext : DbContext
    {
        public MyKartContext() : base("name=MyKartContext")
        {
        }

        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }

        // TODO: Create "Order" model
    }
}
