﻿using MyKart.Core.Models;
using MyKart.Core.Repositories;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace MyKart.Persistence.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly MyKartContext db;

        public ProductRepository(MyKartContext db)
        {
            this.db = db;
        }

        public void Add(Product newProduct)
        {
            db.Products.Add(newProduct);
        }

        public void Delete(Product product)
        {
            db.Products.Remove(product);
        }

        public Product Get(int? id)
        {
            if (id == null)
                return null;

            return db.Products.Find(id);
        }

        public List<Product> GetAll()
        {
            return db.Products.ToList();
        }

        public void Update(Product product)
        {
            db.Entry(product).State = EntityState.Modified;
        }
    }
}